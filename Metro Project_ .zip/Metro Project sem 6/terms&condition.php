<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gujarat Metro  System - Terms & Conditions</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      color: #fff;
      
      background-color: #393f4f !important;
    }
  

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
     
}
    h1 {
      text-align: center;
      color: #fff;
    }
    p {
      margin-bottom: 20px;
    }
    .highlight {
      background-color: cornflowerblue;
      padding: 5px 10px;
      border-radius: 5px;
      color: #fff;
      font-weight: bold;
    }
    ul {
      list-style-type: disc;
      margin-left: 20px;
    }
    .section-title {
      color: #fff;
      margin-top: 30px;
    }
    .section-content {
      border: #fff 9px solid;
      background-color: #393f4f !important;
      padding: 20px;
      border-radius: 5px;
    }
    .footer {
      text-align: center;
      margin-top: 50px;
      color: #fff;
      text-decoration: none;
    }
  </style>
</head>
<body>

  

<div class="container">
  <h1>Gujarat Metro Management System</h1>
  
  <div class="section-content">
    <h2 class="section-title">Terms & Conditions</h2>
    <p>Welcome to the Gujarat Metro Management System. These terms and conditions outline the rules and regulations for the use of our website.</p>
    
    <p>Please read these terms and conditions carefully before using our website. By accessing or using our website, you agree to abide by these terms and conditions.</p>
    
    <h3 class="highlight">1. Intellectual Property Rights</h3>
    <p>The content of this website, including text, graphics, logos, images, and software, is the property of the Gujarat Metro Management System and is protected by intellectual property laws.</p>
    
    <h3 class="highlight">2. Use License</h3>
    <p>You may view, download, and print pages from the website for your own personal use, subject to the restrictions set out in these terms and conditions.</p>
    
    <h3 class="highlight">3. Limitations</h3>
    <ul>
      <li>You must not republish material from this website.</li>
      <li>You must not sell, rent, or sub-license material from the website.</li>
      <li>You must not reproduce, duplicate, copy, or otherwise exploit material on this website for commercial purposes.</li>
    </ul>
  </div>
  
  <div class="footer">
    <div class="splash-footer "><a href = "index.php" class="footer" >Home</a></div>
    <p>&copy; 2024 Gujarat Metro Management System. All rights reserved.</p>
  </div>
</div>

</body>
</html>
