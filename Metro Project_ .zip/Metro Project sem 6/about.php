<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="about.css">
     
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  <noscript>
	<link rel="stylesheet" href="includes/css/noscript.css" />
</noscript>

  <title>About Gujarat Metro</title>
 
</head>
<body>
  
	<div id="page-wrapper">

		<nav class="navbar navbar-expand-lg bg_blue text-white">
			<div class="container-fluid ">
				<a class="navbar-brand text-white" href="#">Gujarat Metro</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav me-auto mb-2 mb-lg-0">
						<li class="nav-item">
							<a class="nav-link text-white active" aria-current="page" href="index.php">Home</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="pass-login.php">Make Reservation</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="employee/emp-login.php">Employee Login</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="admin/emp-login.php">Admin Login</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="terms&condition.php">Terms & Conditions</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="about.php">About us</a>
						</li>

					
					</ul>
				</div>
			</div>
		</nav>
	</div>

 
  <div >
    <section >
     <div class="maindiv">
		<h2 class="h21">Welcome to Gujarat Metro</h2>
      <p class="text-white" id="per1">The Gujarat Metro is a state-of-the-art rapid transit system serving the cities of Ahmedabad, Surat, and Rajkot. With modern trains, spacious stations, and advanced technology,Gujarat Metro aims to provide efficient and comfortable transportation to millions of passengers.
		
		<br>The Gujarat Metro is a rapid transit system serving the state of Gujarat, India.<br>The project aims to provide efficient, reliable, and sustainable transportation solutions to the residents of Gujarat, particularly in its major cities like Ahmedabad and Surat.
	</p>
	</div>
	<div class="maindiv2">
      <h2 class="h21">Our Mission</h2>
      <p  class="text-white">Our mission is to revolutionize public transportation in Gujarat by offering a safe, reliable, and environmentally friendly metro system that connects key areas of the cities and promotes sustainable urban development.</p>
	</div> 
	<div class="maindiv3 text-white">
	  <h2 style="padding-top: 2%;">Key Features</h2>
      
        <p >Fast and punctual trains</p>
        <p>Accessible stations with modern facilities</p>
        <p>Integration with other modes of transport</p>
        <p>Smart ticketing and fare collection systems</p>
        <p>Environmentally friendly operations</p>
    
	</div>
	<div class="maindiv4">
      <h2 style="padding-top: 2%;">Future Expansion</h2>
      <p  class="text-white">The Gujarat Metro is continuously expanding to serve more areas and accommodate the growing population.<br> Future plans include extensions to new suburbs and integration with other transportation networks to create a seamless travel experience.</p>
    </section>
</div>
</div>
<section id="footer">
	<div class="inner">
		<h2 class="major">Contact US </h2>
		
		<ul class="contact text-white" style="padding: left 2px;">
		<i style="font-size:24px" class="fa">&#xf015;</i>
				Metro Reservation System<br />
				
				<p><strong> you prefer to contact us via phone or visit our office, here are our details:</strong></p>
				
				<li><i style="font-size:24px" class="fa">&#xf098;</i><strong>Phone:</strong> 07923248572</li><br>
				
				<li><i class="material-icons">&#xe0c8;</i><strong>Address:</strong> 1st Floor, BLOCK 1, KARMAYOGI BHAVAN, Sector 10A, Sector 10, Gandhinagar, Gujarat 382010</li><br>
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3666.80013026945!2d72.64996067517049!3d23.213953479040086!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395c2b42322f590f%3A0xbe17bd0b4dca2ae7!2sGujarat%20Metro%20Rail%20Corporation%20(GMRC)%20Limited%20(Registered%20Office)!5e0!3m2!1sen!2sin!4v1709360519787!5m2!1sen!2sin" width="800" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
     
   

			</li>
			</ul>
		<ul class="copyright text-white">
			
			<li>&copy;Metro Reservation System.</li>
			<li>Developed By:Deep Vaghela,Ravi Sankliya,Harshad Bundheliya,Ketan Ladumore</li>
		</ul>
	</div>
</section>
<script src="includes/js/jquery.min.js"></script>
	<script src="includes/js/jquery.scrollex.min.js"></script>
	<script src="includes/js/browser.min.js"></script>
	<script src="includes/js/breakpoints.min.js"></script>
	<script src="includes/js/util.js"></script>
	<script src="includes/js/main.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">

	</script>

</body>
</html>
