<div class="splash-footer">
    &copy; 2019 - <?php echo date ('Y');?>Metro Reservation System | Developed By :Deep Vaghela,Ravi Sankliya,Harshad Bundheliya<br>Ketan Ladumore
</div>
