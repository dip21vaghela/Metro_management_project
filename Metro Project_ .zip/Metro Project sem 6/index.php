<!DOCTYPE HTML>

<html>

<head>
	<title>Metro Reservation System</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="includes/css/main.css" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

	<noscript>
		<link rel="stylesheet" href="includes/css/noscript.css" />
	</noscript>

	<style>
		.bg_blue {
    background-color: #393f4f !important;
}
	</style>
</head>

<body class="is-preload">


	<div id="page-wrapper">

		<nav class="navbar navbar-expand-lg bg_blue text-white">
			
			<div class="container-fluid ">
				<a class="navbar-brand text-white" href="#">Gujarat Metro</a>
				<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
					<span ><i style='font-size:24px' class='fas'>&#xf039;</i>
</span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav me-auto mb-2 mb-lg-0">
						<li class="nav-item">
							<a class="nav-link text-white active" aria-current="page" href="index.php">Home</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="pass-login.php">Make Reservation</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="employee/emp-login.php">Employee Login</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="admin/emp-login.php">Admin Login</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="terms&condition.php">Terms & Conditions</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="about.php">About us</a>
						</li>

					
					</ul>
				</div>
			</div>
		</nav>

		<section id="banner">
			<div class="inner">
				<div class="logo"><span class="icon solid fa-train"></span></div>
				<h2>Gujarat Metro Booking</h2>
				<p class="text-white">Best, Simple, and User Friendly Way To Reserve Train Tickets Effectively</a></p>
			</div>
		</section>
		<div class="home">
			<div class="title">
				<h1 class="homeh1 font-effect-shadow-multiple" >Gujarat Metro Booking</h1>
				<br>
				<P class="homep text-white">Welcome to Gujarat Metro, where the future of transportation unfolds before your eyes.<br>
					Our efficient, eco-friendly, and elevated network is designed to redefine your travel experience.<br>
					With seamless connectivity between cities, Gujarat Metro brings communities together and unites people from all walks of life. <br>
					Experience the transformative power of urban mobility as we revolutionize travel and enhance lives across the state.<br>
					<button type="button" class="btn btn-outline-white" style="margin-top: 4%; "><a href="pass-my-booked-train.php" class="text-white"style=" text-decoration:none;">Book Now</a></button>
			</div>
			<div class="slide">
				<div class="photo">
					<img src="photos/1.png" alt="loading" id="img" style="  height: 200px;
        width: 190px; ">
				</div>
				<div class="photo">
					<img src="photos/2.png" alt="loading" id="img" style="  height: 200px;
        width: 190px;">
				</div>
			</div>
			<div class="slide">
				<div class="photo">
					<img src="photos/3.png" alt="loading" id="img" style="  height: 200px;
        width: 190px;">
				</div>
				<div class="photo">
					<img src="photos/4.png" alt="loading" id="img" style="  height: 200px;
        width: 190px;">
				</div>
				<div class="photo">
					<img src="photos/5.png" alt="loading" id="img" style="  height: 200px;
          width: 190px;">
				</div>
			</div>
			<div class="slide">
				<div class="photo">
					<img src="photos/6.png" alt="loading" id="img" style="  height: 200px;
        width: 190px;">
				</div>
				<div class="photo">
					<img src="photos/7.png" alt="loading" id="img" style="  height: 200px;
        width: 190px;">
				</div>
			</div>
		</div>

		</section>
		<section id="sec2">
			<h1 class="font-effect-shadow-multiple" style="text-align: center; margin-top: 8%;"> Our Project </h1>
			<div class="mainpart">
				<div class="parts"><img src="photos/ahemdabad.jpg" alt="loading" srcset="">
					<h5 id="h4"  class="homeh1 font-effect-shadow-multiple">Ahemdabad Metro </h5>
					<p class="details text-white">2</p>
					<p class="pera text-white">No.of Phase</p>
					<p class="details text-white">54</p>
					<p class="pera text-white">Total Stations</p>
					<p class="details text-white">4</p>
					<p class="pera text-white">Underground stations</p>
					<p class="details text-white">29</p>
					<p class="pera text-white">Oprational Station</p>
					<p class="details text-white">68.29</p>
					<p class="pera text-white"> Network Lenght(Km)</p>
				</div>
				<div class="parts"><img src="photos/surat.jpg" alt="loading" srcset="">
					<h5 id="h4" class="font-effect-shadow-multiple text-white">Surat Metro</h5>
					<p class="details text-white">1</p>
					<p class="pera text-white">No.of Phase</p>
					<p class="details text-white">38</p>
					<p class="pera text-white">Total Stations</p>
					<p class="details text-white">6</p>
					<p class="pera text-white">Underground stations</p>
					<p class="details text-white">0</p>
					<p class="pera text-white">Oprational Station</p>
					<p class="details text-white">38.40</p>
					<p class="pera text-white"> Network Lenght(Km)</p>
				</div>
		</section>
		<section id="sec3">
			<h2 class="homeh2 font-effect-shadow-multiple text-white">Gujrat Metro Map </h2>
			<div class="map">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3777314.872995804!2d68.6848901800457!3d22.399496801005473!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959051f5f0ef795%3A0x861bd887ed54522e!2sGujarat!5e0!3m2!1sen!2sin!4v1709265982349!5m2!1sen!2sin" width="100%" bordar="30px solid white" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
			</div>
		</section>

		<section id="footer">
			<div class="inner">
				<h2 class="major">Get in touch</h2>

				<ul class="contact text-white">
					<li class="icon solid fa-home">
						Metro Reservation System<br />
						PHP Project<br />

					</li>
					<li class="icon solid fa-phone text-white">(+254) 127-0000</li>
					<li class="icon solid fa-envelope text-white"><a href="#" class="text-white"style=" text-decoration:none;">mail@orrs.com</a></li>
					<li class="icon brands fa-twitter text-white"><a href="#"  class="text-white"style=" text-decoration:none;">twitter.com/Orrs</a></li>
					<li class="icon brands fa-facebook-f text-white"><a href="#"  class="text-white"style=" text-decoration:none;">facebook.com/orrs</a></li>
					<li class="icon brands fa-instagram text-white"><a href="#"  class="text-white " style=" text-decoration:none;">instagram.com/orrs</a></li>
				</ul>
				<ul class="copyright text-white">
					<li>&copy;Metro Reservation System.</li>
					<li>Developed By:Deep Vaghela,Ravi Sankliya,Harshad Bundheliya,Ketan Ladumore</li>
				</ul>
			</div>
		</section>

	</div>

	<!-- Scripts -->
	<script src="includes/js/jquery.min.js"></script>
	<script src="includes/js/jquery.scrollex.min.js"></script>
	<script src="includes/js/browser.min.js"></script>
	<script src="includes/js/breakpoints.min.js"></script>
	<script src="includes/js/util.js"></script>
	<script src="includes/js/main.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>